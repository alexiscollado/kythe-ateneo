<?php
get_header();
 ?>
<body>
<!--Start of Container-->
	<div class="container">
	<div class="cloud1"></div>
	<div class="cloud2"></div>
	<div class="ftk"></div>
		<!--Start of Wrapper-->
		<div class="wrapper">
			<!--Start of Main Content-->
			<div class="main-content">

				<img class="logo img-responsive" src="<?php echo get_bloginfo('template_url'); ?>/img/kythelogo.png" alt="">
				<img class="kitefly img-responsive" src="<?php echo get_bloginfo('template_url'); ?>/img/kitefly.png" alt="">
				<img class="mainsub img-responsive" src="<?php echo get_bloginfo('template_url'); ?>/img/mainsub.png" alt="">
			</div>
			
			<!--Start of Icon Navigation-->

			<nav class="navigation">
				<ul class="nav-ul2">
					<a href="" class="nav-link">
						<div class="link-block2">
							<li class="nav-item"><img class="icon hvr-bounce-in" src="<?php echo get_bloginfo('template_url'); ?>/img/aboutus.png" alt=""></li>
						</div>
					</a>
					<a href="" class="nav-link">
						<div class="link-block2">
							<li class="nav-item"><img class="icon hvr-bounce-in" src="<?php echo get_bloginfo('template_url'); ?>/img/partner.png" alt=""></li>
						</div>
					</a>
					<a href="" class="nav-link">
						<div class="link-block2">
							<li class="nav-item"><img class="icon hvr-bounce-in" src="<?php echo get_bloginfo('template_url'); ?>/img/events.png" alt=""></li>
						</div>
					</a>
					<a href="" class="hide nav-link">
						<img class="logo2 hide" src="<?php echo get_bloginfo('template_url'); ?>/img/kythelogo2.png" alt="">
					</a>
					<a href="#blog" class="nav-link smoothScroll">
						<div class="link-block2">
							<li class="nav-item"><img class="icon hvr-bounce-in" src="<?php echo get_bloginfo('template_url'); ?>/img/blog.png" alt=""></li>
						</div>
					</a>
					<a href="" class="nav-link">
						<div class="link-block2">
							<li class="nav-item"><img class="icon hvr-bounce-in" src="<?php echo get_bloginfo('template_url'); ?>/img/getinvolved.png" alt=""></li>
						</div>
					</a>
					<a href="" class="nav-link">
						<div class="link-block2">
							<li class="nav-item"><img class="icon hvr-bounce-in" src="<?php echo get_bloginfo('template_url'); ?>/img/contact.png" alt=""></li>
						</div>
					</a>
				</ul>
			</nav>

			<!--End of Icon Navigation-->

			<!--Start of Sticky Navigation-->

			<nav id="header" class="sticky-navigation">
				<ul class="nav-ul">
					<a href="" class="nav-link">
						<div class="link-block">
							<li class="nav-item">ABOUT US</li>
						</div>
					</a>
					<a href="" class="nav-link">
						<div class="link-block">
							<li class="nav-item">PARTNERS</li>
						</div>
					</a>
					<a href="" class="nav-link">
						<div class="link-block">
							<li class="nav-item">EVENTS</li>
						</div>
					</a>
					<a href="" class="nav-link">
						<img class="logo2" src="img/kythelogo2.png" alt="">
					</a>
					<a href="" class="nav-link">
						<div class="link-block">
							<li class="nav-item">BLOG</li>
						</div>
					</a>
					<a href="" class="nav-link">
						<div class="link-block">
							<li class="nav-item">GET INVOLVED</li>
						</div>
					</a>
					<a href="" class="nav-link">
						<div class="link-block">
							<li class="nav-item">CONTACT US</li>
						</div>
					</a>
				</ul>

			</nav>

			<!--End of Sticky Navigation-->
			

			<!--Hidden Nav-->
			
			<nav id="header2"class="sticky-navigation2">
				<ul class="nav-ul">
					<a href="" class="nav-link hidden">
						<div class="link-block">
							<li class="nav-item">ABOUT US</li>
						</div>
					</a>
					<a href="" class="nav-link hidden">
						<div class="link-block">
							<li class="nav-item">PARTNERS</li>
						</div>
					</a>
					<a href="" class="nav-link hidden">
						<div class="link-block">
							<li class="nav-item">EVENTS</li>
						</div>
					</a>
					<a href="" class="nav-link hidden">
						<img class="logo2" src="img/kythelogo2.png" alt="">
					</a>
					<a href="" class="nav-link hidden">
						<div class="link-block">
							<li class="nav-item">BLOG</li>
						</div>
					</a>
					<a href="" class="nav-link hidden">
						<div class="link-block">
							<li class="nav-item">GET INVOLVED</li>
						</div>
					</a>
					
						<div class="link-block">
							<li class="nav-item-important"><strong><a href="" class="nav-link2">LOGIN</a></strong></li>
						</div>
				</ul>

			</nav>


			<!--End Hidden Nav-->

			<!--End of Main Content-->

			<!--Start of About Us-->
			<div class="about-us">
				<div class="mission-vision">
					<img class="ribbon" src="img/vision.png" alt="">

					<p>The primary vision of Kythe-Ateneo is to <strong>uplift the spirits</strong> of pediatric patients and their families through <strong>hospital volunteerism.</strong></p>

					<p>Kythe-Ateneo also aims to <strong>promote awareness and advocacy of the Child Life Program</strong> in the Philippines and consequently, <strong>form its members into responsible and compassionate persons.</strong></p>

					<p>In line with this, Kythe-Ateneo has three aspects:</p>
					
					<div class="col-flex justify-between vision">
						<div class="col-3"><img class="vision-pic" src="img/memberformations.png" alt=""><br><p>MEMBER FORMATIONS</p></div>
						<div class="col-3"><img class="vision-pic" src="img/hospitalvisits.png" alt=""><br><p>HOSPITAL VISITS</p></div>
						<div class="col-3"><img class="vision-pic" src="img/projectinvolvement.png" alt=""><br><p>PROJECT INVOLVEMENT</p></div>
					</div>
					<img class="ribbon" src="img/mission.png" alt="">

					<p>Guided by Kythe-Ateneo’s vision, the organization’s primary mission is <strong>to provide direct (psychosocial) and indirect (financial) assistance</strong> to pediatric patients with chronic illnesses and their families in AFP Medical Center (AFPMC), Philippine Orthopedic Center (POC), Quirino Memorial Medical Center (QMMC), Philippine Children's Medical Center (PCMC), Philippine Heart Center (PHC), and National Children’s Hospital (NCH); and in so doing, form its members into responsible and compassionate persons.</p>


					<p>Psycho-social support will be given in the form of prepared <strong>structured activities</strong> for the pediatric patients, including both bedside and playroom activities held in the hospital. Indirect assistance will be given in the form of money or goods which must be channeled through Kythe Foundation, Inc.</p>


					<p>Kythe’s secondary mission is <strong>to promote awareness of what the Kythe Child Life Program is</strong> through on and off campus advocacy and finance activities.</p>

				</div>
				
				<div class="childlife-program">
					<h1 class="stylish-h1">The Child Life Program</h1>
					<p>The objective of the Kythe Child Life Program is <strong>to provide psycho-social support that alleviates the anxiety of pediatric patients who suffer from illnesses</strong> such as cancer, heart condition, kidney disease, and blood disorders. The Kythe Child Life Program specializes in <strong>promoting optimum growth, fostering development and helping the children cope with the challenge of hospitalization</strong></p>
				</div>

				<img class="transition1" src="img/transition1.png" alt="">
				

			</div>
			<!--End of About Us-->
			<!--Start of Partners-->
			<div class="partners">
				<h1 class="h1-partners">PARTNERS</h1>
				<img class="hospitals" src="img/hospitals.png" alt="">
				<div class="col-flex justify-between vision">
						<div class="col-3"><img class="vision-pic" src="img/hospital1.png" alt=""><br><p>AFP MEDICAL CENTER</p><br>
						<ul class="social">
							<li><a href=""><img class="hvr-grow small-icon" src="img/facebook.png" alt=""></a></li>
							<li><a href=""><img class="hvr-grow small-icon" src="img/location.png" alt=""></a></li>
						</ul>
						</div>
						<div class="col-3"><img class="vision-pic" src="img/hospital2.png" alt=""><br><p>PHILIPPINE ORTHOPEDIC CENTER</p><br>
						<ul class="social">
							<li><a href=""><img class="hvr-grow small-icon" src="img/facebook.png" alt=""></a></li>
							<li><a href=""><img class="hvr-grow small-icon" src="img/location.png" alt=""></a></li>
						</ul></div>
						<div class="col-3"><img class="vision-pic" src="img/hospital3.png" alt=""><br><p>PHILIPPINE CHILDREN'S CENTER</p><br>
						<ul class="social">
							<li><a href=""><img class="hvr-grow small-icon" src="img/facebook.png" alt=""></a></li>
							<li><a href=""><img class="hvr-grow small-icon" src="img/location.png" alt=""></a></li>
						</ul></div>
				</div>
				<div class="col-flex justify-between vision">
						<div class="col-3"><img class="vision-pic" src="img/hospital4.png" alt=""><br><p>PHILIPPINE HEART CENTER</p><br>
						<ul class="social">
							<li><a href=""><img class="hvr-grow small-icon" src="img/facebook.png" alt=""></a></li>
							<li><a href=""><img class="hvr-grow small-icon" src="img/location.png" alt=""></a></li>
						</ul></div>
						<div class="col-3"><img class="vision-pic" src="img/hospital5.png" alt=""><br><p>PHILIPPINE CHILDREN'S HOSPITAL</p><br>
						<ul class="social">
							<li><a href=""><img class="hvr-grow small-icon" src="img/facebook.png" alt=""></a></li>
							<li><a href=""><img class="hvr-grow small-icon" src="img/location.png" alt=""></a></li>
						</ul></div>
						<div class="col-3"><img class="vision-pic" src="img/hospital6.png" alt=""><br><p>PHILIPPINE HEART CENTER</p><br>
						<ul class="social">
							<li><a href=""><img class="small-icon" src="img/facebook.png" alt=""></a></li>
							<li><a href=""><img class="small-icon" src="img/location.png" alt=""></a></li>
						</ul></div>
				</div>

				<img class="foundation" src="img/foundation.png" alt="">
				<p class="desc">Kythe-Ateneo is the primary student-arm of Kythe Foundation, Inc., a non-profit, non-stock organization aimed towards <strong>improving the quality of life among hospitalized children with cancer and other chronic illnesses</strong. To get to know more about our mother organization, visit them at <strong>www.kythe.org</strong></p>
			</div>
			<!--End of Partners-->	
<h2 align=center id="blog"><b style="color:orange;" >Blog</b></h2>
<?php
$postlist = get_posts( "&orderby=date &order=desc" );
$posts = array();
$recent=true;
$i=0;
foreach ( $postlist as $post ) 
{
	if ($i<3)
	{
		if($i==0){
 
			echo the_title("<h3 ><font color='red'>","</font></h3>");
			$recent = false;
	
		   echo the_time(' F jS, Y, g:i a');

		}
		else
		{

		;
			echo the_title("<h4><font color='blue'>","</font></h4>");
			$recent = false;
	
		   echo the_time(' F jS, Y, g:i a');
		   
		}
	}
	
	
	$i+=1;
}     
?>

</div>



		</div>
		<!--End of Wrapper-->


	</div>
<!--End of Container-->
<script src="SmoothScroll.js"></script>
</body>
</html>