<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Kythe Website</title>
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/normalize.css" type="text/css" />
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/hover.css" type="text/css" />
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/style.css" type="text/css" />	
	
	 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  <script type="text/javascript" src="jquery.sticky.js"></script>
  <script>
    $(window).load(function(){
      $("#header").sticky({ topSpacing: 0 });
    });

    
    $(window).load(function(){
      $("#header2").sticky({ topSpacing: 50 });
    });
  
  </script>


</head>